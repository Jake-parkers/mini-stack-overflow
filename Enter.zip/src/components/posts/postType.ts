export enum PostType {
    ANSWER = "answer",
    QUESTION = "question"
}