export enum SearchType {
    TAG = "tag",
    ANSWER = "answer",
    QUESTION = "question",
    USER = "user"
}